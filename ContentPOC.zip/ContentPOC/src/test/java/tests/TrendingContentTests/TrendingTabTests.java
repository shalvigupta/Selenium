package tests.TrendingContentTests;

import Base.ActionClass;
import Base.BaseDriver;
import Pages.HomePage;
import commonUtils.ConfigReader;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TrendingTabTests extends ActionClass {

    BaseDriver base = new BaseDriver();
    ConfigReader configReader = new ConfigReader();


    @BeforeMethod
    public void setUp() {
        String url = configReader.getPropertyValue("url");
        base.chooseDriver();
        getUrl(url);
    }

    @Test
    public void testPlayAndPauseVideo() throws InterruptedException {
        HomePage homePage = PageFactory.initElements(driver, HomePage.class);
        homePage.clickFirstItem();
        homePage.clickPlayButton();
        homePage.waitForContentToLoad();
        homePage.clickAdPauseButton();
        homePage.waitForPlay();
        homePage.clickAdPlayButton();
        homePage.waitForAdToFinish();
        homePage.staticWaitForTwoMinutes();
        homePage.pauseThreeminutesOfPlayback();

    }

    @AfterMethod
    public void closeBrowser() {
        if (driver != null) {
            driver.close();
        }
    }
}
