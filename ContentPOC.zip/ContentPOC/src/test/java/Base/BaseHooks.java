package Base;


import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseHooks {

    @BeforeClass
    public void beforeTestClass(){
        //TODO
    }


    @AfterClass
    public void afterTestClass(){
        //TODO
    }
}
