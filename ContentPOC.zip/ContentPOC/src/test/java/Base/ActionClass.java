package Base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class ActionClass extends BaseDriver {

    public void getUrl(String url) {
        driver.get(url);
    }

    public void clickElement(WebElement element) {
        waitForElement(element);
        element.click();
    }

    public void waitForElement(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void sendKeysInElement(WebElement element, String keys) {
        waitForElement(element);
        element.sendKeys(keys);
    }

    public String getTextFromElement(WebElement element) {
        waitForElement(element);
        return element.getText();
    }

    public void waitForElementInvisibility(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.invisibilityOf(element));
    }

    public void moveToElement(WebElement element){
        new Actions(driver).moveToElement(element).perform();
    }

    public int doesElementExist(String xpath){
        return driver.findElements(By.xpath(xpath)).size();
    }
}