package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import commonUtils.ConfigReader;

public class BaseDriver {

    public static WebDriver driver;
    ConfigReader configReader = new ConfigReader();

    public void chooseDriver() {
        String browser = configReader.getPropertyValue("browser");
        if (browser.equalsIgnoreCase("chrome")) {
            initializeChromeDriver();
        } else if (browser.equalsIgnoreCase("firefox")) {
            //Can Create new function to handle more browsers
            System.out.println("TODO");

        } else {
            System.out.println("Not Configured yet");
        }


    }

    public void initializeChromeDriver() {
        String chromeDriver = configReader.getPropertyValue("webdriver.chrome.driver");
        System.setProperty("webdriver.chrome.driver", chromeDriver);
        driver = new ChromeDriver();
    }
}