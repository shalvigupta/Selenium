package Pages;

import Base.ActionClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Reporter;

public class HomePage extends ActionClass {

    ActionClass actionClass = new ActionClass();

    @FindBy(xpath = "//div[@data-swiper-slide-index='0']")
    WebElement firstItem;

    @FindBy(xpath = "//button[@title='Play Video']")
    WebElement playButton;

    @FindBy(xpath = "//button[@title='Pause']")
    WebElement pause;

    @FindBy(xpath = "//button[@title='Play']")
    WebElement playAds;

    @FindBy(xpath = "//span[@data-test-id='Text']")
    WebElement adBar;

    @FindBy(xpath = "//div[@class='vjs-current-time-display']")
    WebElement currentTimeDisplay;

    @FindBy(xpath = "//div[@class='vjs-text-track-display']")
    WebElement clickOnScreen;

    public void clickFirstItem() {
        actionClass.clickElement(firstItem);
        Reporter.log("Clicked on House Rules");
    }

    public void clickPlayButton() {
        actionClass.clickElement(playButton);
        Reporter.log("Clicked play");
    }

    public void waitForContentToLoad() throws InterruptedException {
        for (int i=0;i<100;i++) {
            int size = actionClass.doesElementExist("//button[@title='Pause']");
            if (size > 0) {
                break;
            } else {
                Thread.sleep(1000);
            }
        }
    }

    public void waitForPlay() throws InterruptedException {
        for (int i=0;i<100;i++) {
            int size = actionClass.doesElementExist("//button[@title='Play']");
            if (size > 0) {
                break;
            } else {
                Thread.sleep(1000);
            }
        }
    }

    public void clickAdPauseButton() {
        actionClass.moveToElement(pause);
        actionClass.clickElement(pause);
        Reporter.log("Clicked pause ad");
    }

    public void clickAdPlayButton() {
        actionClass.clickElement(playAds);
        Reporter.log("Clicked play ads");
    }

    public void waitForAdToFinish(){
        waitForElementInvisibility(adBar);
    }

    public void staticWaitForTwoMinutes() throws InterruptedException {
        Reporter.log("Going into 2 mins wait");
        Thread.sleep(120000);
        Reporter.log("Out of 2 mins wait");
    }
    public void pauseThreeminutesOfPlayback() throws InterruptedException {
            actionClass.moveToElement(clickOnScreen);
        for (int i = 0; i <= 100; i++) {
            actionClass.moveToElement(currentTimeDisplay);
            String text = actionClass.getTextFromElement(currentTimeDisplay);
            if (text.contains("3:0")) {
                actionClass.moveToElement(pause);
                actionClass.clickElement(pause);
                break;
            } else {
                Thread.sleep(1000);
            }
        }
    }
}